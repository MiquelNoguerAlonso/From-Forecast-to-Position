# Market Microstructure Trilogy — Paper III

**From Forecast to Position**  
DOI: <https://doi.org/10.5281/zenodo.22759534>  
Fixed manuscript date: **15 September 2026**

The main document is `p3_forecast.tex`. Compile it with pdfLaTeX and BibTeX;
`latexmk -pdf p3_forecast.tex` performs the required passes. The bibliography,
generated `.bbl`, five publication-resolution PNG figures, and every file
needed to compile the deposited PDF are included.

The figures are deterministic and use no market data. After installing the
packages in `verification/requirements.txt`, they can be regenerated with:

    python verification/generate_manuscript_figures.py --paper 3 --output figures

`Trilogy_Citations.bib` contains the definitive BibTeX records for all three
papers. The trilogy uses a fixed star citation architecture: Paper III cites
Paper I and does not cite Paper II.
